from sympy import Matrix, pretty
from pandas import read_csv
import argparse


def nullspace_solve(input_file):

    D_in = read_csv(input_file, index_col=0)

    D = Matrix(D_in)
    S = D.nullspace()

    dim = D_in.index.tolist()
    var = map(str.strip, D_in.columns.tolist())

    dim_str = ' '.join(dim)
    var_str = ' '.join(var)

    output_str = 'Dimensions: ' + dim_str + '\nVariables: ' + var_str + '\n\nD = \n\n' + pretty(D) + '\n\nS = \n\n' + pretty(S) + '\n'

    return output_str
