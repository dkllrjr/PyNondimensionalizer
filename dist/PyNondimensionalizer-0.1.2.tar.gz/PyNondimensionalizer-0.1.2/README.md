# PyNondimensionalizer

A simple little command line program in python to help find nondimensional numbers, such as the Reynold's number, Rossby number, or more.

See the [documentation](https://alaskanresearcher.dev/pynondimensionalizer/pynondimensionalizer.html) for more information.
